Instructions
============

  * Copy all files from `WinUAE` into your WinUAE folder.

  * You'll need to install ReShade to use the `Commodore-1084S.ini` ReShade
    preset.

  * It's a good idea to save the filter settings as presets from the included
    configs.


  * The included `CRT-A2080-*` shaders are based on the
    `CRT-A2080-HiRes-SmartRes-Interlace` shader from Guest's WinUAE shader
    pack available from here:

      https://github.com/guestrr/WinUAE-Shaders

    They're essentially presets with tweaked parameters, but because WinUAE
    doesn't support shader presets, I had to make several copies of Guest's
	original shader.


  * Optionally, copy `Scripts/SetGfx` into `SYS:S` in your emulated Amiga if
	you wish to change scaling settings from the CLI or AmigaDOS scripts.


  * For further info, check out my article:

      https://blog.johnnovak.net/2022/04/15/achieving-period-correct-graphics-in-personal-computer-emulators-part-1-the-amiga/


  ----
  John Novak, 2022
  https://www.johnnovak.net/
